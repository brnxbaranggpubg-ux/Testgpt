#!/usr/bin/env python3
from pathlib import Path
import json, shutil, sys, re, base64
root=Path(sys.argv[1] if len(sys.argv)>1 else 'project')
java=root/'src/main/java/com/baroxvs/client'

# 1) Separate the code by responsibility; the client bootstrap stays in the root package.
move={
 'BaroxConfig.java':'config',
 'BaroxMenuScreen.java':'gui','HudEditorScreen.java':'gui','Ui.java':'gui','L10n.java':'gui',
 'HudRenderer.java':'hud',
 'CosmeticCatalog.java':'cosmetic','CosmeticEngine.java':'cosmetic','ModuleCatalog.java':'cosmetic',
 'MusicEngine.java':'audio','DesktopPcmOutput.java':'audio',
 'SkinStudio.java':'render','SkyboxEngine.java':'render',
 'Theme.java':'theme','Themes.java':'theme'
}
for fn,pkg in move.items():
    src=java/fn; dst=java/pkg/fn
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.move(str(src),str(dst))
    text=dst.read_text().replace('package com.baroxvs.client;',f'package com.baroxvs.client.{pkg};',1)
    imports=[]
    for class_file,class_pkg in move.items():
        simple=class_file[:-5]
        if class_pkg != pkg and simple != dst.stem:
            imports.append(f'import com.baroxvs.client.{class_pkg}.{simple};')
    imports.append('import com.baroxvs.client.BaroxVsClient;')
    lines=text.splitlines(); at=1
    while at<len(lines) and not lines[at].strip(): at+=1
    lines[at:at]=sorted(set(imports))+['']
    dst.write_text('\n'.join(lines)+'\n')
# Rebuild imports for root bootstrap / mixin, then prune generated unused imports.
for path in java.rglob('*.java'):
    if path.name in move and any(f'/{pkg}/' in path.as_posix() for pkg in move.values()):
        continue
    text=path.read_text()
    if not text.startswith('package '): continue
    lines=text.splitlines(); at=1
    while at<len(lines) and not lines[at].strip(): at+=1
    imports=[f'import com.baroxvs.client.{pkg}.{fn[:-5]};' for fn,pkg in move.items()]
    imports += ['import com.baroxvs.client.BaroxVsClient;']
    lines[at:at]=sorted(set(imports))+['']
    path.write_text('\n'.join(lines)+'\n')
for path in java.rglob('*.java'):
    lines=path.read_text().splitlines(); out=[]
    for line in lines:
        if line.startswith('import com.baroxvs.client.') and line.endswith(';'):
            simple=line[:-1].split('.')[-1]
            body='\n'.join(x for x in lines if x!=line and not x.startswith('import '))
            if not re.search(r'\b'+re.escape(simple)+r'\b',body): continue
        out.append(line)
    path.write_text('\n'.join(out)+'\n')

# Public cross-package API surfaces.
p=java/'hud/HudRenderer.java'; s=p.read_text().replace('final class HudRenderer {','public final class HudRenderer {',1)
s=s.replace('    HudRenderer(BaroxConfig cfg) {','    public HudRenderer(BaroxConfig cfg) {',1)
for a,b in [('    void toast(','    public void toast('),('    void tick(','    public void tick('),('    void render(','    public void render(')]: s=s.replace(a,b,1)
p.write_text(s)
p=java/'gui/Ui.java'; s=p.read_text().replace('final class Ui {','public final class Ui {',1)
s=s.replace('    static final int ','    public static final int ')
s=re.sub(r'(?m)^    static (?!class)([\w<>\[\], ?]+?\s+[A-Za-z_$][\w$]*\()',r'    public static \1',s)
p.write_text(s)
p=java/'gui/L10n.java'; s=p.read_text().replace('final class L10n {','public final class L10n {',1)
s=s.replace('    static String tr(','    public static String tr(',1).replace('    static String module(','    public static String module(',1); p.write_text(s)
# Drop inaccessible/unused package-private imports from the main bootstrap and mixin.
p=java/'BaroxVsClient.java'; s=p.read_text()
for line in ['import com.baroxvs.client.audio.DesktopPcmOutput;\n','import com.baroxvs.client.gui.L10n;\n','import com.baroxvs.client.gui.Ui;\n']:
    s=s.replace(line,'')
p.write_text(s)
p=java/'mixin/LocalSkinMixin.java'; s=p.read_text()
s=re.sub(r'import com\.baroxvs\.client\..*?;\n','',s)
s=s.replace('package com.baroxvs.client.mixin;','package com.baroxvs.client.mixin;\n\nimport com.baroxvs.client.BaroxVsClient;\nimport com.baroxvs.client.render.SkinStudio;',1)
p.write_text(s)

# 2) Correct the wing/effects rendering path. Keep it in BEFORE_ENTITIES so it queues into
# the world renderer's entity buffers, but use the depth-tested translucent entity layer.
p=java/'cosmetic/CosmeticEngine.java'; s=p.read_text()
s=s.replace('import net.minecraft.client.render.VertexConsumer;','import net.minecraft.client.render.VertexConsumer;\nimport net.minecraft.client.render.OverlayTexture;\nimport net.minecraft.client.render.LightmapTextureManager;\nimport net.minecraft.util.Identifier;\nimport net.minecraft.registry.tag.FluidTags;\nimport net.minecraft.util.hit.BlockHitResult;')
s=s.replace('    private enum Shape { DOT, DIAMOND, STAR, PETAL, SHARD, HEART, RING, CUBE, ORB }','    private static final Identifier COSMETIC_TEXTURE = Identifier.of("baroxvs", "textures/misc/white.png");\n\n    private enum Shape { DOT, DIAMOND, STAR, PETAL, SHARD, HEART, RING, CUBE, ORB }')
s=s.replace('''        WorldRenderEvents.BEFORE_ENTITIES.register(this::renderWingsBehindPlayer);
        WorldRenderEvents.AFTER_ENTITIES.register(this::renderWorldEffects);''','''        // Use the regular entity-translucent buffer: depth test stays active, depth writes do not.
        WorldRenderEvents.BEFORE_ENTITIES.register(this::renderWorldEffects);''')
start=s.index('    /** Wings are emitted before the player model so the torso naturally occludes their roots. */')
end=s.index('    private void renderWings(',start)
s=s[:start]+'''    /**
     * Queues wings and ambient geometry in Minecraft's normal entity-translucent batch.
     * This keeps depth testing against the scene and prevents cosmetic alpha surfaces from
     * writing to the depth buffer, so they cannot mask the vanilla water surface.
     */
    private void renderWorldEffects(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || context.consumers() == null) return;
        VertexConsumer output = context.consumers().getBuffer(RenderLayer.getEntityTranslucent(COSMETIC_TEXTURE));
        Vec3d camera = context.camera().getPos();
        // Never draw BAROX world geometry while the camera is submerged or the crosshair
        // targets a water block. This leaves the vanilla water surface and underwater view untouched.
        boolean cameraInWater = client.world.getFluidState(net.minecraft.util.math.BlockPos.ofFloored(
                camera.x, camera.y, camera.z)).isIn(FluidTags.WATER);
        boolean targetingWater = client.crosshairTarget instanceof BlockHitResult hit
                && client.world.getFluidState(hit.getBlockPos()).isIn(FluidTags.WATER);
        if (cameraInWater || targetingWater) return;
        PlayerEntity player = client.player;
        float partial = context.tickCounter().getTickDelta(false);
        if (config.isOn("wings")) renderWings(output, camera, player, partial);
        if (config.isOn("cape")) renderCape(output, camera, player, partial);
        renderCompanionShape(output, camera, player, partial);
        renderSparks(output, camera, context.camera().getRotation());
    }

'''+s[end:]
s=s.replace('''        // DEBUG_QUADS is POSITION_COLOR in 1.21.4; color completes each vertex.
        out.vertex((float) (position.x - camera.x), (float) (position.y - camera.y),
                (float) (position.z - camera.z)).color(color);''','''        // Entity-translucent format: POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL.
        out.vertex((float) (position.x - camera.x), (float) (position.y - camera.y),
                (float) (position.z - camera.z), color, 0.5f, 0.5f,
                OverlayTexture.DEFAULT_UV, LightmapTextureManager.MAX_LIGHT_COORDINATE,
                0.0f, 1.0f, 0.0f);''')
p.write_text(s)

# Procedural sky uses the same depth-tested translucent layer; the panorama remains textured.
p=java/'render/SkyboxEngine.java'; s=p.read_text()
s=s.replace('import net.minecraft.client.render.LightmapTextureManager;','import net.minecraft.client.render.LightmapTextureManager;\nimport net.minecraft.client.render.OverlayTexture;')
s=s.replace('    private static final float RADIUS = 190.0f;','    private static final float RADIUS = 190.0f;\n    private static final Identifier WHITE_TEXTURE = Identifier.of("baroxvs", "textures/misc/white.png");')
s=s.replace('context.consumers().getBuffer(RenderLayer.getDebugQuads())','context.consumers().getBuffer(RenderLayer.getEntityTranslucent(WHITE_TEXTURE))')
s=s.replace('''        out.vertex(v.x, v.y, v.z)
                .color(color)
                .texture(0.5f, 0.5f)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(LightmapTextureManager.MAX_LIGHT_COORDINATE)
                .normal(0.0f, 1.0f, 0.0f);''','''        out.vertex(v.x, v.y, v.z, color, 0.5f, 0.5f,
                OverlayTexture.DEFAULT_UV, LightmapTextureManager.MAX_LIGHT_COORDINATE,
                0.0f, 1.0f, 0.0f);''')
s=s.replace('''        out.vertex(x, y, z)
                .color(color)
                .texture(0.5f, 0.5f)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(LightmapTextureManager.MAX_LIGHT_COORDINATE)
                .normal(0.0f, 1.0f, 0.0f);''','''        out.vertex(x, y, z, color, 0.5f, 0.5f,
                OverlayTexture.DEFAULT_UV, LightmapTextureManager.MAX_LIGHT_COORDINATE,
                0.0f, 1.0f, 0.0f);''')
s=s.replace('''        out.vertex(v.x, v.y, v.z)
                .color(255, 255, 255, 255)
                .texture(v.u, v.v)
                .overlay(0)
                .light(LightmapTextureManager.MAX_LIGHT_COORDINATE)
                .normal(0.0f, 1.0f, 0.0f);''','''        out.vertex(v.x, v.y, v.z, 0xFFFFFFFF, v.u, v.v, OverlayTexture.DEFAULT_UV,
                LightmapTextureManager.MAX_LIGHT_COORDINATE, 0.0f, 1.0f, 0.0f);''')
s=s.replace('''        // Sky geometry is camera-centred; the world renderer expects camera-relative vertices.
        out.vertex(v.x, v.y, v.z).color(color);''','''        // Sky geometry is camera-centred; provide every attribute required by the translucent entity shader.
        out.vertex(v.x, v.y, v.z, color, 0.5f, 0.5f, OverlayTexture.DEFAULT_UV,
                LightmapTextureManager.MAX_LIGHT_COORDINATE, 0.0f, 1.0f, 0.0f);''')
s=s.replace('''        // Diamond order avoids a self-crossing quad and keeps stars crisp at every angle.
        out.vertex((float)(x-size), (float)y, (float)z).color(color);
        out.vertex((float)x, (float)(y+size), (float)z).color(color);
        out.vertex((float)(x+size), (float)y, (float)z).color(color);
        out.vertex((float)x, (float)(y-size), (float)z).color(color);''','''        // Diamond order avoids a self-crossing quad and keeps stars crisp at every angle.
        skyVertex(out, (float)(x-size), (float)y, (float)z, color);
        skyVertex(out, (float)x, (float)(y+size), (float)z, color);
        skyVertex(out, (float)(x+size), (float)y, (float)z, color);
        skyVertex(out, (float)x, (float)(y-size), (float)z, color);''')
s=s.replace('''    private record Vertex(float x, float y, float z, float u, float v) {}''','''    private static void skyVertex(VertexConsumer out, float x, float y, float z, int color) {
        out.vertex(x, y, z, color, 0.5f, 0.5f, OverlayTexture.DEFAULT_UV,
                LightmapTextureManager.MAX_LIGHT_COORDINATE, 0.0f, 1.0f, 0.0f);
    }

    private record Vertex(float x, float y, float z, float u, float v) {}''')
s=s.replace('''        Vec3d camera = context.camera().getPos();
        if (config.isOn("custom_sky") && textureId != null) {''','''        Vec3d camera = context.camera().getPos();
        // Do not add any BAROX sky geometry while the active camera is submerged.
        if (client.world.getFluidState(net.minecraft.util.math.BlockPos.ofFloored(
                camera.x, camera.y, camera.z)).isIn(net.minecraft.registry.tag.FluidTags.WATER)) return;
        if (config.isOn("custom_sky") && textureId != null) {''')

p.write_text(s)

# Cloth Config advanced screen and launcher on the Settings page.
cloth='''package com.baroxvs.client.gui;

import com.baroxvs.client.config.BaroxConfig;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Advanced settings screen built with the public Cloth Config API. */
public final class BaroxClothConfigScreen {
    private BaroxClothConfigScreen() {}

    public static Screen create(Screen parent, BaroxConfig config) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Text.translatable("baroxvs.cloth.title"))
                .setSavingRunnable(config::save);
        ConfigEntryBuilder entries = builder.entryBuilder();

        ConfigCategory cosmetics = builder.getOrCreateCategory(Text.translatable("baroxvs.cloth.category.cosmetics"));
        cosmetics.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.wings"), config.isOn("wings"))
                .setDefaultValue(true).setSaveConsumer(v -> config.setOn("wings", v)).build());
        cosmetics.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.membrane"), config.isOn("wing_membrane"))
                .setDefaultValue(true).setSaveConsumer(v -> config.setOn("wing_membrane", v)).build());
        cosmetics.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.outline"), config.isOn("wing_outline"))
                .setDefaultValue(true).setSaveConsumer(v -> config.setOn("wing_outline", v)).build());
        cosmetics.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.harness"), config.isOn("wing_harness"))
                .setDefaultValue(false).setSaveConsumer(v -> config.setOn("wing_harness", v)).build());
        cosmetics.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.runes"), config.isOn("wing_runes"))
                .setDefaultValue(true).setSaveConsumer(v -> config.setOn("wing_runes", v)).build());
        cosmetics.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.cape"), config.isOn("cape"))
                .setDefaultValue(false).setSaveConsumer(v -> config.setOn("cape", v)).build());
        cosmetics.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.pet"), config.isOn("pet"))
                .setDefaultValue(false).setSaveConsumer(v -> config.setOn("pet", v)).build());

        ConfigCategory effects = builder.getOrCreateCategory(Text.translatable("baroxvs.cloth.category.effects"));
        effects.addEntry(entries.startIntSlider(Text.translatable("baroxvs.cloth.density"), config.style("particle_density"), 0, 2)
                .setDefaultValue(1).setTextGetter(v -> Text.translatable(switch (v) { case 0 -> "baroxvs.cloth.density.low"; case 2 -> "baroxvs.cloth.density.high"; default -> "baroxvs.cloth.density.medium"; }))
                .setSaveConsumer(v -> config.styles.put("particle_density", v)).build());
        effects.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.aura"), config.isOn("aura"))
                .setDefaultValue(false).setSaveConsumer(v -> config.setOn("aura", v)).build());
        effects.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.ambient"), config.isOn("sky_mood"))
                .setDefaultValue(false).setSaveConsumer(v -> config.setOn("sky_mood", v)).build());

        ConfigCategory hud = builder.getOrCreateCategory(Text.translatable("baroxvs.cloth.category.hud"));
        hud.addEntry(entries.startBooleanToggle(Text.translatable("baroxvs.cloth.hud.visible"), config.hudVisible)
                .setDefaultValue(true).setSaveConsumer(v -> config.hudVisible = v).build());
        hud.addEntry(entries.startIntSlider(Text.translatable("baroxvs.cloth.hud.scale"), Math.round(config.hudScale * 100), 55, 125)
                .setDefaultValue(90).setTextGetter(v -> Text.literal(v + "%"))
                .setSaveConsumer(v -> config.hudScale = v / 100.0f).build());
        hud.addEntry(entries.startIntSlider(Text.translatable("baroxvs.cloth.hud.opacity"), Math.round(config.hudOpacity * 100), 0, 100)
                .setDefaultValue(76).setTextGetter(v -> Text.literal(v + "%"))
                .setSaveConsumer(v -> config.hudOpacity = v / 100.0f).build());
        return builder.build();
    }
}
'''
(java/'gui/BaroxClothConfigScreen.java').write_text(cloth)
p=java/'gui/BaroxMenuScreen.java'; s=p.read_text()
s=s.replace('import net.minecraft.client.gui.DrawContext;','import net.minecraft.client.MinecraftClient;\nimport net.minecraft.client.gui.DrawContext;')
s=s.replace('''    private void drawSettings(DrawContext c) {
        drawModulePage(c, ModuleCatalog.MISC, true);
    }''','''    private void drawSettings(DrawContext c) {
        Theme t = Themes.current(cfg);
        int x = mainX + 14, y = bodyY, w = bodyW - 28;
        Ui.roundRect(c, x, y, x + w, y + 48, 8, PANEL_SOFT);
        Ui.text(c, textRenderer, L10n.tr("cloth.open.title"), x + 12, y + 9, WHITE, 0.82f, true);
        Ui.text(c, textRenderer, L10n.tr("cloth.open.subtitle"), x + 12, y + 25, MUTED, 0.66f, false);
        int buttonW = 150, buttonX = x + w - buttonW - 10;
        Ui.roundRect(c, buttonX, y + 9, buttonX + buttonW, y + 39, 6, Ui.alpha(t.primary(), 0x58));
        Ui.textCentered(c, textRenderer, L10n.tr("cloth.open.button"), buttonX + buttonW / 2, y + 20, WHITE, 0.72f, true);
        hits.add(new Hit(buttonX, y + 7, buttonX + buttonW, y + 41,
                () -> MinecraftClient.getInstance().setScreen(BaroxClothConfigScreen.create(this, cfg)), null,
                L10n.tr("cloth.open.tooltip")));
        drawModuleGrid(c, filterModules(ModuleCatalog.inCategory(ModuleCatalog.MISC)), x, y + 58, w, bodyH - 58, t);
    }''')
p.write_text(s)

# Build metadata and dependency versions.
p=root/'build.gradle'; s=p.read_text()
s=s.replace('repositories { mavenCentral() }', '''repositories {
    mavenCentral()
    maven { url 'https://maven.shedaniel.me/' }
    maven {
        name = 'GeckoLib'
        url = 'https://dl.cloudsmith.io/public/geckolib3/geckolib/maven/'
        content { includeGroup 'software.bernie.geckolib' }
    }
}''')
s=s.replace('''    // Pure-Java MP3 decoding. The Android AudioTrack output is accessed reflectively.
    modImplementation include("com.googlecode.soundlibs:jlayer:1.0.1.4")''','''    // Pure-Java MP3 decoding. The Android AudioTrack output is accessed reflectively.
    modImplementation include("com.googlecode.soundlibs:jlayer:1.0.1.4")

    // Cloth Config powers the advanced settings screen; it remains an external mod dependency.
    modImplementation("me.shedaniel.cloth:cloth-config-fabric:${project.cloth_config_version}") {
        exclude(group: 'net.fabricmc.fabric-api')
    }

    // GeckoLib API is available to the optional model/animation integration without shading it.
    modCompileOnly "software.bernie.geckolib:geckolib-fabric-${project.minecraft_version}:${project.geckolib_version}"''')
s=s.replace("archiveFileName = 'BAROX-VS-v006.jar'", "archiveFileName = 'BAROX-VS-v007.jar'")
p.write_text(s)
p=root/'gradle.properties'; s=p.read_text()
s=s.replace('fabric_api_version=0.119.2+1.21.4','fabric_api_version=0.119.2+1.21.4\ncloth_config_version=17.0.144\ngeckolib_version=4.8.5')
s=s.replace('mod_version=0.6.0','mod_version=0.7.0'); p.write_text(s)
p=root/'src/main/resources/fabric.mod.json'; d=json.loads(p.read_text())
d['description']='Client-side visual studio for Minecraft 1.21.4 Fabric: liquid-glass HUD, Cloth Config settings, automatic language, custom sky, local skin studio and depth-safe translucent cosmetics.'
d['depends']['cloth-config']='>=17.0.144'
d['suggests']={'geckolib':'>=4.8.5','entity_model_features':'*','entity_texture_features':'*'}
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

# Language strings: keep UI language tied to Minecraft's language table.
strings={
'en_us.json':{'baroxvs.cloth.title':'BAROX VS — Advanced Settings','baroxvs.cloth.category.cosmetics':'Cosmetics','baroxvs.cloth.category.effects':'Visual Effects','baroxvs.cloth.category.hud':'HUD','baroxvs.cloth.wings':'Enable wings','baroxvs.cloth.membrane':'Wing membrane','baroxvs.cloth.outline':'Wing outline','baroxvs.cloth.harness':'Wing harness','baroxvs.cloth.runes':'Wing runes','baroxvs.cloth.cape':'Cape effects','baroxvs.cloth.pet':'Companion','baroxvs.cloth.density':'Effect density','baroxvs.cloth.density.low':'Low','baroxvs.cloth.density.medium':'Medium','baroxvs.cloth.density.high':'High','baroxvs.cloth.aura':'Aura ring','baroxvs.cloth.ambient':'Ambient sky effects','baroxvs.cloth.hud.visible':'Show HUD','baroxvs.cloth.hud.scale':'HUD scale','baroxvs.cloth.hud.opacity':'HUD opacity','baroxvs.cloth.open.title':'Advanced configuration','baroxvs.cloth.open.subtitle':'Fine-tune cosmetics, effects and HUD through Cloth Config.','baroxvs.cloth.open.button':'OPEN CONFIG','baroxvs.cloth.open.tooltip':'Open advanced options (Cloth Config API required)'},
'de_de.json':{'baroxvs.cloth.title':'BAROX VS — Erweiterte Einstellungen','baroxvs.cloth.category.cosmetics':'Kosmetik','baroxvs.cloth.category.effects':'Visuelle Effekte','baroxvs.cloth.category.hud':'HUD','baroxvs.cloth.wings':'Flügel aktivieren','baroxvs.cloth.membrane':'Flügelmembran','baroxvs.cloth.outline':'Flügelkontur','baroxvs.cloth.harness':'Flügelgeschirr','baroxvs.cloth.runes':'Flügelrunen','baroxvs.cloth.cape':'Umhangeffekte','baroxvs.cloth.pet':'Begleiter','baroxvs.cloth.density':'Effektdichte','baroxvs.cloth.density.low':'Niedrig','baroxvs.cloth.density.medium':'Mittel','baroxvs.cloth.density.high':'Hoch','baroxvs.cloth.aura':'Aurar-Ring','baroxvs.cloth.ambient':'Umgebungseffekte des Himmels','baroxvs.cloth.hud.visible':'HUD anzeigen','baroxvs.cloth.hud.scale':'HUD-Größe','baroxvs.cloth.hud.opacity':'HUD-Deckkraft','baroxvs.cloth.open.title':'Erweiterte Konfiguration','baroxvs.cloth.open.subtitle':'Kosmetik, Effekte und HUD mit Cloth Config fein einstellen.','baroxvs.cloth.open.button':'KONFIG ÖFFNEN','baroxvs.cloth.open.tooltip':'Erweiterte Optionen öffnen (Cloth Config API erforderlich)'},
'tr_tr.json':{'baroxvs.cloth.title':'BAROX VS — Gelişmiş Ayarlar','baroxvs.cloth.category.cosmetics':'Kozmetikler','baroxvs.cloth.category.effects':'Görsel Efektler','baroxvs.cloth.category.hud':'HUD','baroxvs.cloth.wings':'Kanatları etkinleştir','baroxvs.cloth.membrane':'Kanat zarı','baroxvs.cloth.outline':'Kanat dış çizgisi','baroxvs.cloth.harness':'Kanat koşumu','baroxvs.cloth.runes':'Kanat rünleri','baroxvs.cloth.cape':'Pelerin efektleri','baroxvs.cloth.pet':'Yoldaş','baroxvs.cloth.density':'Efekt yoğunluğu','baroxvs.cloth.density.low':'Düşük','baroxvs.cloth.density.medium':'Orta','baroxvs.cloth.density.high':'Yüksek','baroxvs.cloth.aura':'Aura halkası','baroxvs.cloth.ambient':'Çevresel gökyüzü efektleri','baroxvs.cloth.hud.visible':'HUD göster','baroxvs.cloth.hud.scale':'HUD boyutu','baroxvs.cloth.hud.opacity':'HUD saydamlığı','baroxvs.cloth.open.title':'Gelişmiş yapılandırma','baroxvs.cloth.open.subtitle':'Kozmetikleri, efektleri ve HUD öğelerini ayrıntılı ayarla.','baroxvs.cloth.open.button':'AYARLARI AÇ','baroxvs.cloth.open.tooltip':'Cloth Config ile gelişmiş ayarları aç'}}
for name,items in strings.items():
    path=root/'src/main/resources/assets/baroxvs/lang'/name
    data=json.loads(path.read_text()); data.update(items); path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

# Tiny white texture is tinted by vertex colours in the entity-translucent shader.
white=root/'src/main/resources/assets/baroxvs/textures/misc/white.png'
white.parent.mkdir(parents=True,exist_ok=True)
white.write_bytes(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l0sAAAAASUVORK5CYII='))
(root/'BUILD_VERSION.txt').write_text('BAROX VS v007\nMinecraft Java 1.21.4 | Fabric | Java 21\n')
readme=root/'README.md'; text=readme.read_text().replace('v006','v007')
text=text.replace('The selected Violet Void theme is the fresh-install default.', 'The selected Violet Void theme is the fresh-install default. The advanced Settings page includes a Cloth Config screen.')
text=text.replace('- **Player-attached wings:**', '- **Water-safe cosmetic layer:** wings, cape and ambient geometry use Minecraft’s entity-translucent render layer. BAROX world geometry is skipped while the camera is submerged or the crosshair targets a water block, preserving the normal vanilla water view.\n- **Player-attached wings:**')
text=text.replace('The music player requires a direct MP3 stream URL.', 'Cloth Config API 17.0.144 is required for the advanced Settings screen. GeckoLib 4.8.5 is a compile-time optional model API; EMF/ETF are optional companion mods. The existing wings still use BAROX geometry and are not yet a GeckoLib GeoModel rig. Cloth Config must be installed in the mods folder; GeckoLib is not required at runtime.\n\nThe music player requires a direct MP3 stream URL.')
text=text.replace('## Scope and test note', '## Render architecture\n\nMost client rendering hooks use Fabric API events. BAROX deliberately keeps one narrowly scoped mixin for the local skin-texture override; adding more mixins without a specific vanilla hook would increase compatibility risk rather than improve it. The world-render path uses Fabric `BEFORE_ENTITIES` and the standard entity-translucent layer instead of `DEBUG_QUADS`.\n\nSee [`RENDER_COMPATIBILITY.md`](RENDER_COMPATIBILITY.md) for the render and Sodium compatibility notes.\n\n## Scope and test note')
readme.write_text(text)
(root/'THIRD_PARTY_NOTICES.md').write_text('''# Third-party notices — BAROX VS v007\n\nBAROX VS uses these external libraries as dependencies; their source code is not copied into BAROX VS source files.\n\n- **JLayer 1.0.1.4** — GNU Lesser General Public License, version 2.1 (LGPL-2.1). It is packaged as a nested JAR for MP3 decoding.\n- **Cloth Config API 17.0.144 (Fabric)** — GNU Lesser General Public License, version 3.0 only (LGPL-3.0-only). It is an external required mod dependency for the advanced settings screen and is not bundled into BAROX VS.\n- **GeckoLib 4.8.5 (Fabric 1.21.4)** — MIT License. It is a compile-only optional model API; this release's wings continue to use BAROX's own geometry and do not use a GeckoLib GeoModel rig. It is not bundled or required at runtime.\n\nThe BAROX VS source remains separately distributed under the repository's MIT license. Each library's own license continues to apply to that library.\n''')
(root/'RENDER_COMPATIBILITY.md').write_text('''# Rendering and compatibility notes — v007\n\n## Water and transparency\n\nThe v006 cosmetic path used `RenderLayer.getDebugQuads()` for translucent wing and effect geometry. In v007 the custom wing, cape and ambient geometry is queued through `RenderLayer.getEntityTranslucent()` with the complete entity vertex format. BAROX also skips world cosmetics when the active camera is in water or when the crosshair is targeting a water block. The sky renderer is skipped while the camera is submerged. These guards leave the vanilla water rendering path in control.\n\nThis is a source-level correction; it still needs a live Minecraft test in first- and third-person views, including camera submersion and water surfaces.\n\n## Fabric events and mixins\n\nThe client uses Fabric API lifecycle, key-binding, HUD and world-render events for normal features. The one remaining mixin is `LocalSkinMixin`, narrowly scoped to replacing the local player's skin texture. A larger mixin count is not inherently safer or more compatible; adding injections that duplicate public Fabric events would create avoidable conflict points.\n\n## Sodium and renderer interoperability\n\nThe v007 changes avoid direct GL state manipulation and the `DEBUG_QUADS` layer, and submit geometry using the supported world-render consumer. This is a lower-risk path for alternate renderers such as Sodium, but it is not a guarantee of compatibility with every Sodium/Iris combination or every shader pack. Those combinations still require in-game testing.\n''')
print('Applied BAROX VS v007 source transformations to',root)
